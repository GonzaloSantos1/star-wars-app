import React from 'react';
import './_homepage.scss';

export const Homepage = ({characters}) => {
  return <div className='homepage'></div>;
};
